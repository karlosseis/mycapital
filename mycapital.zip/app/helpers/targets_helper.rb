module TargetsHelper
end
